<?php $__env->startSection('content'); ?>

            <div class="card">
                <div class="card-header">Create Product</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="container">
                        <form action="">
                            <div class="form-grop">
                                <label for="">Name</label>
                                <input type="text" name="pname" class="form-control" placeholder="Enter Product Name" required>
                            </div>
                            <div class="form-grop">
                                <label for="">Price</label>
                                <input type="number" name="price" class="form-control" placeholder="Enter Product Price" required>
                            </div>
                            <div class="form-grop">
                                <label for="">Description</label>
                                <input type="text" name="desc" class="form-control" placeholder="Enter Product Description" required>
                            </div>
                            <div class="form-grop">
                                <label for="">Image</label>
                                <input type="file" name="img" class="form-control" required>
                            </div>
                            <div class="form-grop">
                                <label for="">Category</label>
                                <input type="text" name="cat" class="form-control" placeholder="Enter Product Category" required>
                            </div>
                            <div class="form-grop">
                                <input type="submit" class="btn btn-primary btn-block mt-3" required>
                            </div>
                        </form>
                    
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Course\laravel\final\resources\views/admin/product/create.blade.php ENDPATH**/ ?>